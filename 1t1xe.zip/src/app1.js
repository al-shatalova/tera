import "./styles.css";

export default function App1() {
  return (
    <div className="App1">
      Представьте себе, что в эти смутные времена люди не только ищут рецепты от пандемии, но еще и ездят учиться в другую страну. 
      
    </div>
  );
}