import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Какова учеба в Германии во времена пандемии?</h1>
    </div>
  );
}
