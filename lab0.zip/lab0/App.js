import * as React from 'react';
import { Text, View, StyleSheet,Image } from 'react-native';
import Constants from 'expo-constants';
import { Dimensions } from 'react-native';

// You can import from local files

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.im}>
            <Image source={{
              uri: 'https://miro.medium.com/max/4800/0*RpSityCLNI4sOqnU',
            }}
            style={{ width: '100%', height: '35%' }}/> 
      </View>
      
      <View  style={styles.medium}>
          <Text style={styles.paragraph}>
                  Hello world!
          </Text>
      </View>
      
      <View style={styles.footer}>
            <Text >
                Made in and with love
            </Text>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#e2f2fc',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  im: {
    flex:2,
  },
  footer: {
    flex:0.2,
    justifyContent: 'center',
    fontFamily: 'Roboto Slab serif',
    backgroundColor: '#ffe9ec',
    padding: 1,
    textAlign: 'center',
  },
  medium:{
    flex:2,
  }
});
