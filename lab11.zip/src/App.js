import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Путешествия</h1>
    </div>
  );
}