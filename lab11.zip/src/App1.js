import "./styles.css";

export default function App1() {
  return (
    <div className="App1">
      <h1>Пляжный отдых. Вариант бюджетный</h1>
    </div>
  );
}